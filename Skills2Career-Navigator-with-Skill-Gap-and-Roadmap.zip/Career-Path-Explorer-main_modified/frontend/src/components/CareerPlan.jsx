import React, { useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './CareerPlan.css';

const SKILLS = [
  'Python','SQL','Excel','Statistics','Pandas','Machine Learning','Data Visualization',
  'Power BI','Programming','Data Structures','Algorithms','Git','Database','Problem Solving',
  'HTML','CSS','JavaScript','React','REST APIs','Networking','Linux','Cybersecurity Fundamentals',
  'Cryptography','Security Tools','Communication','Leadership','Project Management','Teamwork',
  'CAD','Engineering Drawing','Materials','Thermodynamics','Manufacturing','AutoCAD',
  'Circuit Analysis','Electrical Machines','Power Systems','Control Systems','MATLAB',
  'Microcontrollers','Embedded Systems','C Programming','Design Principles','Creativity','Figma',
  'Typography','Color Theory','Research Methods','Scientific Writing','Data Analysis',
  'Critical Thinking','Experimentation','Subject Knowledge','Lesson Planning','Presentation',
  'Classroom Management','Assessment','Business Analysis','Product Strategy','Market Research',
  'Decision Making','Risk Management','Legal Research','Writing','Case Analysis','Negotiation',
  'Business Fundamentals','Finance','Marketing','General Studies','Current Affairs',
  'Analytical Reasoning','Time Management','Medical Ethics','Biology','Anatomy','Physiology','Clinical Skills'
];

const CareerPlan = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const params = new URLSearchParams(location.search);
  const storedCareer = sessionStorage.getItem('recommendedCareer') || '';
  const [career, setCareer] = useState(params.get('career') || storedCareer);
  const [skills, setSkills] = useState([]);
  const [zeroSkill, setZeroSkill] = useState(false);
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(false);
  const api = import.meta.env.VITE_API_URL || 'http://127.0.0.1:5000';

  const toggleSkill = (skill) => {
    setSkills(prev => prev.includes(skill) ? prev.filter(s => s !== skill) : [...prev, skill]);
    setZeroSkill(false);
  };

  const submit = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${api}/api/career-plan`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ career, skills: zeroSkill ? [] : skills })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setPlan(data);
      sessionStorage.setItem('recommendedCareer', career);
    } catch (e) {
      alert(e.message || 'Could not generate the career plan.');
    } finally {
      setLoading(false);
    }
  };

  const skillOptions = useMemo(() => SKILLS, []);

  return (
    <div className="career-plan">
      <div className="plan-header">
        <button className="back-btn" onClick={() => navigate('/dashboard/quiz')}>← Back to Career Quiz</button>
        <h2>Skill Gap & Career Roadmap</h2>
        <p>Find missing skills and get a personalized learning path — even if you are starting from zero.</p>
      </div>

      <div className="plan-card">
        <label>Recommended / Selected Career</label>
        <input value={career} onChange={e => setCareer(e.target.value)} placeholder="e.g. Data Scientist" />

        <div className="zero-skill-row">
          <label className="zero-check">
            <input type="checkbox" checked={zeroSkill} onChange={e => {setZeroSkill(e.target.checked); if(e.target.checked) setSkills([]);}} />
            I have no skills yet (start from Level 0)
          </label>
        </div>

        {!zeroSkill && (
          <>
            <label>Current Skills</label>
            <div className="skill-picker">
              {skillOptions.map(skill => (
                <button key={skill} type="button" className={skills.includes(skill) ? 'selected' : ''} onClick={() => toggleSkill(skill)}>
                  {skill}
                </button>
              ))}
            </div>
          </>
        )}

        <button className="generate-btn" onClick={submit} disabled={!career || loading}>
          {loading ? 'Generating...' : 'Generate Skill Gap & Roadmap'}
        </button>
      </div>

      {plan && (
        <div className="results">
          <div className="summary-grid">
            <div><span>Career</span><strong>{plan.career}</strong></div>
            <div><span>Level</span><strong>{plan.level}</strong></div>
            <div><span>Skills Missing</span><strong>{plan.skill_gap_count}</strong></div>
            <div><span>Skill Match</span><strong>{plan.skill_match_percent}%</strong></div>
          </div>

          <div className="gap-card">
            <h3>Skill Gap Analysis</h3>
            <div className="skill-status">
              <div><h4>✓ Skills You Have</h4>{plan.skills_have.length ? plan.skills_have.map(s => <span className="have" key={s}>{s}</span>) : <p>No matching skills yet — the roadmap starts from the basics.</p>}</div>
              <div><h4>✕ Skills to Learn</h4>{plan.missing_skills.length ? plan.missing_skills.map(s => <span className="missing" key={s}>{s}</span>) : <p>You currently cover the mapped skills.</p>}</div>
            </div>
          </div>

          <div className="roadmap-card">
            <h3>{plan.is_zero_skill ? 'Beginner-to-Career Roadmap' : 'Personalized Career Roadmap'}</h3>
            <div className="roadmap">
              {plan.roadmap.map(step => (
                <div className="roadmap-step" key={step.stage}>
                  <div className="step-number">{step.stage}</div>
                  <div><h4>{step.title}</h4><p>{step.description}</p><div className="roadmap-skills">{step.skills.map(s => <span key={s}>{s}</span>)}</div></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default CareerPlan;
