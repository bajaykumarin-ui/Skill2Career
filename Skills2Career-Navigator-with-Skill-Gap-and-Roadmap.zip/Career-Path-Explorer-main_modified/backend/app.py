import os
import warnings
import joblib
import pandas as pd
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
from sklearn.exceptions import InconsistentVersionWarning
from sentence_transformers import SentenceTransformer

# ================== Setup Flask ==================
warnings.filterwarnings("ignore", category=InconsistentVersionWarning)

app = Flask(__name__)
CORS(app)  # allow frontend access

BASE = os.path.dirname(__file__)

# ================== Load Quiz ML Model ==================
try:
    quiz_model = joblib.load(os.path.join(BASE, "models", "career_1200_model.pkl"))
    quiz_vectorizer = joblib.load(os.path.join(BASE, "models", "quiz_vectorizer.pkl"))
    quiz_encoder = joblib.load(os.path.join(BASE, "models", "quiz_label_encoder.pkl"))
    print("✅ Quiz model loaded")
except Exception as e:
    print("⚠️ Could not load quiz model:", e)
    quiz_model = quiz_vectorizer = quiz_encoder = None

print("Loading sentence-transformer (may download model first time)...")
emb_model = SentenceTransformer("all-MiniLM-L6-v2")
print("Embedding model loaded. Embedding dim:", emb_model.get_sentence_embedding_dimension())

# ================== Load Colleges Dataset ==================
try:
    colleges = pd.read_csv(os.path.join(BASE, "data", "colleges.csv"))
    colleges.columns = [c.strip().lower() for c in colleges.columns]  # normalize headers
    print("✅ Colleges dataset loaded with", len(colleges), "rows")
except Exception as e:
    print("⚠️ Could not load colleges dataset:", e)
    colleges = pd.DataFrame()

# ================== ML Routes ==================
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


@app.route("/predict", methods=["POST"])
def predict():
    if quiz_model is None or quiz_vectorizer is None or quiz_encoder is None or emb_model is None:
        return jsonify({"error": "Model or required assets not available"}), 500

    data = request.json
    text_input = data.get("features")  # expecting single string
    if not text_input:
        return jsonify({"error": "No text provided"}), 400

    try:
        # Embedding + TF-IDF features
        emb = emb_model.encode([text_input], convert_to_numpy=True)  # (1, EMB_DIM)
        tfidf = quiz_vectorizer.transform([text_input]).toarray()    # (1, TFIDF_DIM)

        print("embedding shape:", emb.shape, "tfidf shape:", tfidf.shape)

        X = np.hstack([emb, tfidf])

        # Check model input dimensions
        if hasattr(quiz_model, "n_features_in_"):
            expected = quiz_model.n_features_in_
            if X.shape[1] != expected:
                return jsonify({
                    "error": f"Feature shape mismatch: model expects {expected}, got {X.shape[1]}"
                }), 500

        # Predict career
        pred = quiz_model.predict(X)[0]
        career = quiz_encoder.inverse_transform([pred])[0]
        return jsonify({"career": career})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ================== Skill Gap + Personalized Roadmap ==================
# Lightweight career-skill knowledge base. This module works independently
# from the ML model, so it also supports students who have no current skills.
CAREER_SKILL_MAP = {
    "data scientist": ["Python", "SQL", "Statistics", "Pandas", "Machine Learning", "Data Visualization"],
    "data analyst": ["Excel", "SQL", "Statistics", "Python", "Pandas", "Power BI", "Data Visualization"],
    "software engineer": ["Programming", "Data Structures", "Algorithms", "Git", "Database", "Problem Solving"],
    "software developer": ["Programming", "Data Structures", "Algorithms", "Git", "Database", "Problem Solving"],
    "web developer": ["HTML", "CSS", "JavaScript", "Git", "React", "REST APIs"],
    "machine learning engineer": ["Python", "Statistics", "Machine Learning", "Data Structures", "SQL", "Git"],
    "business analyst": ["Excel", "SQL", "Statistics", "Communication", "Business Analysis", "Power BI"],
    "product manager": ["Communication", "Product Strategy", "Market Research", "Project Management", "Data Analysis"],
    "project manager": ["Communication", "Project Management", "Leadership", "Risk Management", "Excel"],
    "cyber security": ["Networking", "Linux", "Cybersecurity Fundamentals", "Python", "Cryptography", "Security Tools"],
    "cybersecurity analyst": ["Networking", "Linux", "Cybersecurity Fundamentals", "Python", "Cryptography", "Security Tools"],
    "mechanical engineer": ["Engineering Drawing", "CAD", "Materials", "Thermodynamics", "Manufacturing", "Problem Solving"],
    "civil engineer": ["Engineering Drawing", "AutoCAD", "Structural Analysis", "Surveying", "Construction", "Project Management"],
    "electrical engineer": ["Circuit Analysis", "Electrical Machines", "Power Systems", "Control Systems", "MATLAB", "Problem Solving"],
    "electronics engineer": ["Circuit Analysis", "Digital Electronics", "Microcontrollers", "Embedded Systems", "C Programming", "Communication"],
    "doctor": ["Biology", "Anatomy", "Physiology", "Clinical Skills", "Communication", "Medical Ethics"],
    "teacher": ["Subject Knowledge", "Communication", "Lesson Planning", "Presentation", "Classroom Management", "Assessment"],
    "civil servant": ["General Studies", "Communication", "Current Affairs", "Analytical Reasoning", "Writing", "Time Management"],
    "manager": ["Communication", "Leadership", "Project Management", "Decision Making", "Excel", "Teamwork"],
    "designer": ["Design Principles", "Creativity", "Figma", "Typography", "Color Theory", "Portfolio"],
    "entrepreneur": ["Business Fundamentals", "Communication", "Market Research", "Finance", "Leadership", "Marketing"],
    "lawyer": ["Legal Research", "Communication", "Writing", "Critical Thinking", "Case Analysis", "Negotiation"],
    "scientist": ["Research Methods", "Statistics", "Scientific Writing", "Data Analysis", "Critical Thinking", "Experimentation"],
}

CAREER_ALIASES = {
    "data science": "data scientist", "data scientist": "data scientist",
    "data analytics": "data analyst", "data analyst": "data analyst",
    "software engineering": "software engineer", "software engineer": "software engineer",
    "software developer": "software developer", "web developer": "web developer",
    "machine learning": "machine learning engineer", "machine learning engineer": "machine learning engineer",
    "business analyst": "business analyst", "product manager": "product manager",
    "project manager": "project manager", "cybersecurity": "cybersecurity analyst",
    "cyber security": "cybersecurity analyst", "cybersecurity analyst": "cybersecurity analyst",
    "mechanical engineer": "mechanical engineer", "civil engineer": "civil engineer",
    "electrical engineer": "electrical engineer", "electronics engineer": "electronics engineer",
    "doctor": "doctor", "teacher": "teacher", "civil servant": "civil servant",
    "manager": "manager", "designer": "designer", "entrepreneur": "entrepreneur",
    "lawyer": "lawyer", "scientist": "scientist",
}

def normalize_skill(value):
    return str(value).strip().lower()

def canonical_career(career):
    raw = normalize_skill(career)
    if raw in CAREER_ALIASES:
        return CAREER_ALIASES[raw]
    # fuzzy-ish substring matching for model labels
    for alias, canonical in CAREER_ALIASES.items():
        if alias in raw or raw in alias:
            return canonical
    return raw

def build_roadmap(career_key, missing_skills):
    # Ordered learning path: fundamentals -> core -> tools -> practice -> readiness.
    # Missing skills are placed first; remaining required skills fill the roadmap.
    required = CAREER_SKILL_MAP.get(career_key, [])
    missing_set = {normalize_skill(s) for s in missing_skills}
    ordered = [s for s in required if normalize_skill(s) in missing_set]
    ordered += [s for s in required if normalize_skill(s) not in missing_set]
    if not ordered:
        ordered = list(missing_skills)
    n = len(ordered)
    chunks = [
        ("Foundation", "Learn the basic concepts and vocabulary."),
        ("Core Skills", "Build the main technical or professional skills."),
        ("Tools & Practice", "Use the skills with practical tools and exercises."),
        ("Projects", "Complete small real-world projects and add them to a portfolio."),
        ("Career Ready", "Prepare a resume, portfolio and interview practice.")
    ]
    stages = []
    for i, (name, desc) in enumerate(chunks):
        start = round(i * n / 5)
        end = round((i + 1) * n / 5)
        skills = ordered[start:end]
        if i == 0 and not skills and ordered:
            skills = ordered[:1]
        stages.append({"stage": i + 1, "title": name, "description": desc, "skills": skills})
    return stages

@app.route("/api/skill-gap", methods=["POST"])
def skill_gap():
    data = request.get_json(silent=True) or {}
    career = data.get("career", "")
    current_skills = data.get("skills", [])
    if isinstance(current_skills, str):
        current_skills = [s.strip() for s in current_skills.split(",") if s.strip()]
    key = canonical_career(career)
    required = CAREER_SKILL_MAP.get(key, [])
    current_norm = {normalize_skill(s) for s in current_skills if str(s).strip()}
    have = [s for s in required if normalize_skill(s) in current_norm]
    missing = [s for s in required if normalize_skill(s) not in current_norm]
    return jsonify({
        "career": career,
        "required_skills": required,
        "current_skills": current_skills,
        "skills_have": have,
        "missing_skills": missing,
        "skill_gap_count": len(missing),
        "skill_match_percent": round((len(have) / len(required) * 100), 1) if required else 0
    })

@app.route("/api/career-plan", methods=["POST"])
def career_plan():
    data = request.get_json(silent=True) or {}
    career = data.get("career", "")
    current_skills = data.get("skills", [])
    if isinstance(current_skills, str):
        current_skills = [s.strip() for s in current_skills.split(",") if s.strip()]
    key = canonical_career(career)
    required = CAREER_SKILL_MAP.get(key, [])
    # Empty list is intentional: it creates a Level-0 beginner plan.
    current_norm = {normalize_skill(s) for s in current_skills if str(s).strip()}
    have = [s for s in required if normalize_skill(s) in current_norm]
    missing = [s for s in required if normalize_skill(s) not in current_norm]
    roadmap = build_roadmap(key, missing)
    level = "Beginner (Level 0)" if len(have) == 0 else ("Intermediate" if len(have) < max(2, len(required)//2) else "Advanced")
    return jsonify({
        "career": career,
        "career_key": key,
        "level": level,
        "is_zero_skill": len(have) == 0,
        "required_skills": required,
        "skills_have": have,
        "missing_skills": missing,
        "skill_gap_count": len(missing),
        "skill_match_percent": round((len(have) / len(required) * 100), 1) if required else 0,
        "roadmap": roadmap
    })

# ================== Basic Colleges Route ==================
@app.route("/colleges", methods=["POST"])
def get_colleges():
    if colleges.empty:
        return jsonify({"error": "Colleges dataset not available"}), 500

    data = request.json
    career = data.get("career")
    state = data.get("state")

    if not career or not state:
        return jsonify({"error": "Career and State required"}), 400

    try:
        filtered = colleges[
            (colleges["state"].str.lower() == state.lower()) &
            (colleges["field"].str.lower() == career.lower())
        ]

        if filtered.empty:
            return jsonify({"error": "No colleges found"}), 404

        top5 = filtered.sort_values("ranking").head(5)
        return jsonify(top5.to_dict(orient="records"))
    except Exception as e:
        return jsonify({"error": f"College lookup failed: {str(e)}"}), 500

# ================== Advanced Colleges Routes ==================
@app.route("/api/states", methods=["GET"])
def get_states():
    """Return list of unique states from colleges dataset"""
    if colleges.empty or "state" not in colleges.columns:
        return jsonify([]), 200
    states = sorted(colleges["state"].dropna().unique().tolist())
    return jsonify(states), 200


@app.route("/api/recommend", methods=["POST"])
def recommend():
    """Return college recommendations for a given state"""
    if colleges.empty:
        return jsonify({"error": "No college data available"}), 500

    data = request.get_json()
    if not data or "state" not in data:
        return jsonify({"error": "Missing state parameter"}), 400

    state = data.get("state")
    state_colleges = colleges[colleges["state"].str.lower() == state.lower()]

    if state_colleges.empty:
        return jsonify([]), 200

    def get_best_ranking(rankings):
        valid = [r for r in rankings if pd.notnull(r)]
        return min(valid) if valid else np.inf

    # Build aggregation dict dynamically
    agg_dict = {
        'city': ('city', 'first'),
        'rankings': ('ranking', list),
        'fields': ('field', list),
        'scores': ('score', list)
    }

    if 'website' in state_colleges.columns:  # ✅ only add if exists
        agg_dict['website'] = ('website', 'first')

    grouped = state_colleges.groupby('college_name').agg(**agg_dict).reset_index()
    grouped['best_ranking'] = grouped['rankings'].apply(get_best_ranking)
    grouped.sort_values('best_ranking', inplace=True)

    colleges_list = []
    for _, college in grouped.iterrows():
        college_info = {
            "college_name": college["college_name"],
            "city": college["city"],
            "website": college["website"] if "website" in grouped.columns else None,
            "rankings": [
                {
                    "field": college['fields'][i],
                    "ranking": None if pd.isna(college['rankings'][i]) else int(college['rankings'][i]),
                    "score": None if pd.isna(college['scores'][i]) else float(college['scores'][i])
                } for i in range(len(college['fields']))
            ]
        }
        colleges_list.append(college_info)

    return jsonify(colleges_list), 200

# ================== Run ==================
if __name__ == "__main__":
    app.run(debug=True, port=5000)
